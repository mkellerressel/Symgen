generator module
================

.. automodule:: generator
   :members:
   :undoc-members:
   :show-inheritance:
